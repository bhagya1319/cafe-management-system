<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db_connection.php';

$search_term = '';
$search_by = '';
$total_sales = 0;
$orders = [];
$processed_order_ids = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_term']) && isset($_POST['search_by'])) {
    $search_term = $_POST['search_term'];
    $search_by = $_POST['search_by'];
    $search_column = '';
    switch ($search_by) {
        case 'Order Id':
            $search_column = 'o.order_id';
            break;
        case 'Customer name':
            $search_column = 'c.customer_name';
            break;
        case 'Employee name':
            $search_column = 'u.username';
            break;
        case 'Date':
            $search_column = 'DATE(o.order_date)';
            break;
        case 'Employee ID':
            $search_column = 'u.user_id';
            break;
        case 'Payment Mode':
            $search_column = 'o.payment_status';
            break; 
        default:
            $search_column = 'o.order_id'; 
    }
    
    $sql = "SELECT 
                o.order_id AS order_id, 
                u.username, 
                u.user_id,
                c.customer_name, 
                c.phone_number, 
                o.table_number, 
                o.total_amount, 
                o.payment_status, 
                o.order_date,
                m.item_name, 
                m.item_price, 
                oi.quantity, 
                (m.item_price * oi.quantity) AS item_total 
            FROM Orders o 
            JOIN User u ON o.user_id = u.user_id
            JOIN Customers c ON o.order_id = c.order_id
            JOIN OrderItems oi ON o.order_id = oi.order_id
            JOIN Menu m ON oi.item_id = m.item_id
            WHERE $search_column LIKE ?
            ORDER BY o.order_date asc";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $search_term);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        if (!in_array($row['order_id'], $processed_order_ids)) {
            $total_sales += (float)$row['total_amount'];
            $processed_order_ids[] = $row['order_id']; // Mark this order_id as processed
        }
        // Group order items by order_id
        $orders[$row['order_id']][] = $row;
    }
   
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: lightcyan; 
            margin: 0;
            padding: 20px;
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
        }
        h2 {
            text-align: center;
            color: #343a40; 
            margin-bottom: 20px;
        }
        form {
            text-align: center;
            margin-bottom: 20px;
        }
        .container {
            max-width: 100%;
            margin: 50px auto;
            padding: 20px;
            background-color: white; 
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
        }
        input[type="date"] 
        input[type="text"] 
        {
            padding: 10px;
            border: 1px solid #ced4da; 
            border-radius: 5px;
            font-size: 16px;
            margin-right: 10px;
        }
        button {
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007bff; 
            color: white;
            border: none;
            border-radius: 5px;
            margin-top: 40px;
        }
        button:hover {
            background-color: #0056b3; 
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: black; /* Light border color */
            padding: 12px;
            text-align: left;
            font-size: 14px;
        }
        th {
            background-color:lightcyan; 
            color: #495057; 
        }
        tr:nth-child(even) {
            background-color: white; 
        }
        tr:hover {
            background-color: lightskyblue; 
        }
        .total-sales {
            text-align: center;
            font-size: 18px;
            margin-top: 20px;
            color: #28a745; 
        }
    </style>
</head>
<body>
<div class="container">
<h2>Order History</h2>

<form method="POST">
    <label for="search_by">Search by:</label>
    <select name="search_by" id="search_by" onchange="this.form.submit()">
        <option  value="Order Id" <?php echo ($search_by == 'Order Id') ? 'selected' : ''; ?>>Order ID</option>
        <option value="Customer name" <?php echo ($search_by == 'Customer name') ? 'selected' : ''; ?>>Customer Name</option>
        <option value="Employee ID" <?php echo ($search_by == 'Employee ID') ? 'selected' : ''; ?>>Employee ID</option>
        <option value="Employee name" <?php echo ($search_by == 'Employee name') ? 'selected' : ''; ?>>Employee Name</option>
        <option value="Payment Mode" <?php echo ($search_by == 'Payment Mode') ? 'selected' : ''; ?>>Payment Mode</option>
        <option value="Date" <?php echo ($search_by == 'Date') ? 'selected' : ''; ?>>Date</option>
    </select>
    
<label for="search_term">Search Term:</label>
<?php if (isset($search_by) && $search_by == 'Date') : ?>
    <input type="date" name="search_term" id="search_term" required>
<?php elseif (isset($search_by) && ($search_by == 'Employee Id' || $search_by == 'Order ID')): ?>
    <input type="number" name="search_term" id="search_term" required>
<?php elseif (isset($search_by) && ($search_by == 'Payment Mode')):?>
        <select name="search_term">
                <option value="Cash">Cash</option>
                <option value="QR Scan">QR Scan</option>
                <option value="Credit/Debit">Credit/Debit</option>
        </select>
<?php else : ?>
    <input type="text" name="search_term" id="search_term" required>
<?php endif; ?>

    
    <button type="submit">Search</button>
</form>


<?php
if ($search_term) {
    if($search_by=='Date'){
        $display_order_date = date('d-m-y', strtotime($search_term));
    echo "<h3>Total Sales for $search_by : $display_order_date is Rs " . number_format($total_sales, 2) . "</h3>";
}
else{
    echo "<h3>Total Sales for $search_by : $search_term is Rs " . number_format($total_sales, 2) . "</h3>";
}
} 
else {
    echo "<h3>Total Sales: Rs " . number_format($total_sales, 2) . "</h3>";
}

?>
<table>
    <thead>
        <tr>
            <th>Order Date</th>
            <th>Order ID</th>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Customer Name</th>
            <th>Phone Number</th>
            <th>Table Number</th>
            <th>Item Name</th>
            <th>Item Price</th>
            <th>Quantity</th>
            <th>Item Total</th>
            <th>Payment Mode</th>
        </tr>
    </thead>
    <body>
        <?php
        if ($search_term) {
            if(!empty($orders)){
            foreach ($orders as $order_id => $order_items) {
                $order = $order_items[0]; 
                $rowspan = count($order_items);
                $display_order_date = date('d-m-y', strtotime($order['order_date']));
                echo "<tr>
                        <td rowspan='$rowspan'>" . (isset($display_order_date) ? htmlspecialchars($display_order_date) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['order_id']) ? htmlspecialchars($order['order_id']) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['user_id']) ? htmlspecialchars($order['user_id']) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['username']) ? htmlspecialchars($order['username']) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['customer_name']) ? htmlspecialchars($order['customer_name']) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['phone_number']) ? htmlspecialchars($order['phone_number']) : 'N/A') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['table_number']) ? htmlspecialchars($order['table_number']) : 'N/A') . "</td>
                        <td>" . (isset($order['item_name']) ? htmlspecialchars($order['item_name']) : 'N/A') . "</td>
                        <td>Rs " . (isset($order['item_price']) ? number_format($order['item_price'], 2) : '0.00') . "</td>
                        <td>" . (isset($order['quantity']) ? number_format($order['quantity']) : '0') . "</td>
                        <td>Rs " . (isset($order['item_total']) ? number_format($order['item_total'], 2) : '0.00') . "</td>
                        <td rowspan='$rowspan'>" . (isset($order['payment_status']) ? htmlspecialchars($order['payment_status']) : 'N/A') . "</td>
                    </tr>";
                for ($i = 1; $i < $rowspan; $i++) {
                    $order = $order_items[$i];
                    echo "<tr>
                            <td>" . (isset($order['item_name']) ? htmlspecialchars($order['item_name']) : 'N/A') . "</td>
                            <td>Rs " . (isset($order['item_price']) ? number_format($order['item_price'], 2) : '0.00') . "</td>
                            <td>" . (isset($order['quantity']) ? number_format($order['quantity']) : '0') . "</td>
                            <td>Rs " . (isset($order['item_total']) ? number_format($order['item_total'], 2) : '0.00') . "</td>
                          </tr>";
                }
                echo "<tr>
                        <td colspan='9'></td>
                        <td>Total Amount</td>
                        <td>Rs " . (isset($order['total_amount']) ? number_format($order['total_amount'], 2) : '0.00') . "</td>
                      </tr>";
            }
        } 
        else{
            echo "<tr><td colspan='13'>No orders found for this search term.</td></tr>";
        }
    }
        ?>
    </body>
</table>
<button onclick="window.location.href='index.php'">Back to Menu</button>
    </div>
<?php
$conn->close();
?>
</body>
</html>
