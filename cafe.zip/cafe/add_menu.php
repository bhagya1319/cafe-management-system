<?php
session_start();
include 'db_connection.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_id = $_POST['new-id'];
    $item_name = $_POST['new-name'];
    $item_price = $_POST['new-price'];
    $item_availability = $_POST['availability'];
    $category_name = $_POST['category'];

    if (empty($item_id) || empty($item_name) || empty($item_price) || empty($item_availability) || empty($category_name)) {
        $_SESSION['message'] = 'All fields are required!';
        header('Location: add_menu.php');
        exit;
    }
    $check_query = $conn->prepare("SELECT item_id FROM Menu WHERE item_id = ?");
    $check_query->bind_param('i', $item_id);
    $check_query->execute();
    $check_query->store_result();

    if ($check_query->num_rows > 0) {
        $_SESSION['message'] = "Item ID $item_id already exists!";
        $check_query->close();
        header('Location: add_menu.php');
        exit;
    }
    $check_query->close();

    $stmt = $conn->prepare("INSERT INTO Menu (item_id, item_name, item_price, item_availability, category_name) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('issss', $item_id, $item_name, $item_price, $item_availability, $category_name);

    if ($stmt->execute()) {
        echo "New menu item added successfully!";
        header('Location: index.php');
    } else {
        echo "Error adding menu item: " . $stmt->error;
    }
    $stmt->close(); 
    $conn->close();
    header('Location: index.php'); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Menu Item</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e0f7fa; 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
        }
        .container {
            max-width: 600px;
            width: 100%;
            margin: 20px;
            padding: 20px;
            background-color: white; 
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
        }
        h2 {
            text-align: center;
            color: #00796b; 
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #004d40;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #0288d1;
            border-radius: 5px;
            font-size: 1em;
        }
        button {
            background-color: #0288d1;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            width: 48%;
        }
        button:hover {
            background-color: #0277bd; 
        }
        .button-group {
            display: flex;
            justify-content: space-between;
        }
        .popup {
            background-color: #ffcccb; 
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            color: #d32f2f; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add New Menu Item</h2>
        <?php if (isset($_SESSION['message'])): ?>
            <div class="popup"><?php echo htmlspecialchars($_SESSION['message']); ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        <form action="add_menu.php" method="POST">
            <label for="new-id">Item ID:</label>
            <input type="number" id="new-id" name="new-id" required placeholder="Enter item ID " />

            <label for="new-name">Item Name:</label>
            <input type="text" id="new-name" name="new-name" required placeholder="Enter item name" />

            <label for="new-price">Price:</label>
            <input type="number" id="new-price" name="new-price" step="1" required placeholder="Enter item price" />

            <label for="availability">Availability:</label>
            <select id="availability" name="availability" required value="<?php echo htmlspecialchars($item_availability); ?>">
                <option value="Available">Available</option>
                <option value="Unavailable">Unavailable</option>
            </select>

            <label for="category">Category:</label>
            <select id="category" name="category" required >
                <?php
                $category_sql = "SELECT category_name FROM Categories";
                $category_result = $conn->query($category_sql);
                while ($row = $category_result->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['category_name']) . '">' . htmlspecialchars($row['category_name']) . '</option>';
                }
                ?>
            </select>

            <div class="button-group">
                <button type="submit">Add Item</button>
                <button type="button" onclick="window.location.href='index.php'">Back to Menu</button>
            </div>
        </form>
    </div>
</body>
</html>
