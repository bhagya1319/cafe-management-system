<?php
include 'db_connection.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start(); 
if (!isset($_SESSION['user_id'])) {
    $_SESSION['message'] = "Please login to access this page.";
    header('Location: login.php');
    exit();
}
else{   
    $user_id = $_SESSION['user_id'];
    $username_sql = "SELECT username FROM user WHERE user_id = ?";
    $stmt = $conn->prepare($username_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();  



$category_sql = "SELECT category_name FROM Categories";
$category_result = $conn->query($category_sql);
$categories = [];
while ($row = $category_result->fetch_assoc()) 
{
    $categories[] = $row;
}

$menu_items = [];
foreach ($categories as $category) {
    $sql = "SELECT item_id, item_name, item_price, item_availability FROM Menu WHERE category_name = '" . $conn->real_escape_string($category['category_name']) . "'";
    $result = $conn->query($sql);
    $menu_items[$category['category_name']] = $result->fetch_all(MYSQLI_ASSOC);
}


}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CAFE DELIGHT</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e3f2fd;
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
        }
        .welcome-section {
            font-family: Arial, sans-serif;
            margin: 10px;
            padding: 20px;
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 100%;
            margin-top: 10px;
            text-align: center;
        }
        .welcome-section h2 {
            color: #2196f3;
            text-align: center;
            margin-bottom: 20px;
        }
        .container {
            display: flex;
            justify-content: space-between;
            margin: 10px;
            margin-bottom: 10px;
            max-height: 100%;
        }

        .left-section {
            flex: 1;
            margin-right: 10px;
            padding: 10px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 5px;
            max-height: 100%;
        }

        .right-section {
            flex: 1;
            margin-left: 10px;
            padding: 10px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 5px;
        }

        .menu, .order-section, .summary-section, .payment-section {
            margin-bottom: 20px;
            text-align: center;
        }

        h2, h3 {
            color: #1976d2;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 8px;
            text-align: center;
            border: 1px solid #90caf9;
        }

        th {
            background-color: #1976d2;
            color: white;
        }

        .button {
            background-color: #2196f3;
            color: white;
            padding: 8px 12px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-top: 20px;
        }

        .button:hover {
            background-color: #1976d2;
        }

        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .category-header span {
            font-weight: bold;
        }

        .popup {
            background-color: #ffcc00;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="welcome-section">
    <h2>Welcome to Cafe Delight</h2>
                <label>Address: JORHAT,ASSAM</label>&emsp;&emsp;
                <label>Contact Number: 8011425911</label>&emsp;&emsp;
                <label>License Number: 6867HG</label>&emsp;&emsp;
                <label>GST Number: ER6878HJ687</label>
    </div>


<div class="container">
    <div class="left-section">
        <div class="menu">
            <h3>Menu</h3>
            <?php foreach ($menu_items as $category => $items): ?>
                
                <table>
                    <tr>
                    <div class="category-header">
                        <td colspan='2'>
                            
                            <span><?php echo htmlspecialchars($category); ?></span></td>
                            <td colspan='2'><a href="edit_category.php?category_name=<?php echo urlencode($category); ?>" class="button" );">Edit Category<a></td>
                            <td colspan='2'><a href="delete_category.php?category_name=<?php echo urlencode($category); ?>" class="button" onclick="return confirm('Are you sure you want to delete this category? All items under this category will also be deleted.');">Delete Category</a></td>
                            </div>
                        
                    </tr>
                    <tr>
                        <th>Item ID</th>
                        <th>Item Name</th>
                        <th>Price (Rs)</th>
                        <th>Quantity status</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['item_id']); ?></td>
                            <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                            <td><?php echo htmlspecialchars($item['item_price']); ?></td>
                            <td>
                                <select name="availability-<?php echo $item['item_id']; ?>" onchange="updateAvailability(<?php echo $item['item_id']; ?>, this.value)">
                                    <option value="Available" <?php echo $item['item_availability'] == 'Available' ? 'selected' : ''; ?>>Available</option>
                                    <option value="Unavailable" <?php echo $item['item_availability'] == 'Unavailable' ? 'selected' : ''; ?>>Unavailable</option>
                                </select>
                            </td>
                            <td>
                                <a href="edit_menu.php?item_id=<?php echo $item['item_id']; ?>" class="button">Edit</a>
                            </td>
                            <td>
                                <a href="delete_menu.php?item_id=<?php echo $item['item_id']; ?>" class="button" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endforeach; ?>
            <div style="text-align: center; margin-bottom: 20px;">
                <button class="button" onclick="window.location.href='add_menu.php'">Add Item</button>
                <button class="button" onclick="window.location.href='add_category.php'">Add Category</button>
                <button class="button" onclick="window.location.href='view_orders.php'">Order history</button>
                <button class="button" onclick="window.location.href='login.php'">LOGOUT</button>
            </div>
        </div>
    </div>

    <div class="right-section">
        <div class="order-section">
        <p><strong>Username:</strong> <?php echo htmlspecialchars($username); ?>&emsp;&emsp;&emsp;
        <strong>User ID:</strong> <?php echo htmlspecialchars($user_id, ENT_QUOTES, 'UTF-8'); ?></p>
        <input type="hidden" name="user-id" value="<?php echo htmlspecialchars($user_id, ENT_QUOTES, 'UTF-8'); ?>">
            <h3>Place Your Order</h3>
            <form id="order-form" action="process_payment.php" method="POST">
                <div class="customer-info">
                    <label>Name: 
                        <input type="text" name="customer-name" required /></label>&emsp;
                    <label>Phone: 
                        <input type="text" name="phone-number" required pattern="^\d{10}$" title="Please enter exactly 10 digits." />
                    </label>
                    &emsp;<label>Table No.: <input type="number" name="table-number" required /></label>
                </div>

                <div class="menu-selection">
                    <br><br>
                    <label>Choose an item:</label>
                    <select name="item-select">
                        <?php foreach ($menu_items as $category => $items): ?>
                            <optgroup label="<?php echo htmlspecialchars($category); ?>">
                                <?php foreach ($items as $item): ?>
                                    <option value="<?php echo $item['item_id']; ?>" 
                                        data-price="<?php echo $item['item_price']; ?>"
                                        <?php echo $item['item_availability'] === 'Unavailable' ? 'disabled' : ''; ?>>
                                        <?php echo htmlspecialchars($item['item_name']) . ' - Rs ' . htmlspecialchars($item['item_price']); ?>
                                        <?php echo $item['item_availability'] === 'Unavailable' ? '(Unavailable)' : ''; ?>
                                    </option>
                                <?php endforeach; ?>
                            </optgroup>
                        <?php endforeach; ?>
                    </select>
                    &emsp;&emsp;&emsp;
                    <label>Quantity: <input type="number" name="quantity" min="1" value="1" required /></label>
                    <br><br>
                    &emsp;&emsp;&emsp;<button type="button" class="button" onclick="addToOrder()">Add to Order</button>
                </div>

                <h3>Order Summary</h3>
                <div class="box">
                <div id="order-items"></div> 
                    <table><tr>
                    <td colspan=4><div>Total Amount: Rs <span id="total-amount">0</span></div>
                    <input type="hidden" name="total-price" id="total-price" value="0" /></td></tr>
                    <table>
                    <input type="hidden" name="ordered-items" id="ordered-items" value=""/>

                </div>
                </div>
                <h3>Payment</h3>
                <div class="box">
                &emsp;&emsp;<label>Payment Method: 
                        <select name="payment-type">
                            <option value="CASH">Cash</option>
                            <option value="QR Scan">QR Scan</option>
                            <option value="Credit/Debit">Credit/Debit</option>
                        </select>
                    </label>
                    &emsp;&emsp;
                    <button type="submit" class="button">Place the order</button>
                    &emsp;&emsp;
                    <button class="button" onclick="window.location.href='index.php'">Cancel Order</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>

let orderedItems = []; 
function addToOrder() {
    const selectElement = document.querySelector("select[name='item-select']");
    const itemId = selectElement.value;
    const itemName = selectElement.options[selectElement.selectedIndex].text.split(" - ")[0];
    const itemPrice = parseFloat(selectElement.options[selectElement.selectedIndex].getAttribute("data-price"));
    const quantityInput = document.querySelector("input[name='quantity']");
    const quantity = parseInt(quantityInput.value);

    if (!itemId || isNaN(quantity) || quantity < 1) {
        alert("Please select a valid item and quantity.");
        return;
    }

    // Check if the item already exists in the order
    const existingItem = orderedItems.find(item => item.itemId === itemId);
    if (existingItem) {
        existingItem.quantity += quantity;
        existingItem.itemTotal = existingItem.itemPrice * existingItem.quantity;
    } else {
        const orderItem = {
            itemId,
            itemName,
            itemPrice,
            quantity,
            itemTotal: itemPrice * quantity,
        };
        orderedItems.push(orderItem);
    }

    updateOrderSummary(); // Refresh the order summary
    quantityInput.value = "1"; // Reset quantity input
}

function updateOrderSummary() {
    const orderItemsContainer = document.getElementById("order-items");
    const totalAmount = document.getElementById("total-amount");
    const totalPriceInput = document.getElementById("total-price");
    const orderedItemsInput = document.getElementById("ordered-items");

    // Clear existing summary
    orderItemsContainer.innerHTML = "";

    if (orderedItems.length === 0) {
        orderItemsContainer.innerHTML = "<p>No items added to the order yet.</p>";
        totalAmount.textContent = "0";
        totalPriceInput.value = "0";
        orderedItemsInput.value = "";
        return;
    }

    // Create the table structure
    const table = document.createElement("table");
    table.innerHTML = `
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody></tbody>
    `;

    const tableBody = table.querySelector("tbody");
    let totalOrder = 0;

    orderedItems.forEach((item, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.itemName}</td>
            <td>Rs ${item.itemPrice.toFixed(2)}</td>
            <td>
                <button onclick="decreaseQuantity(${index})">-</button>
                ${item.quantity}
                <button onclick="increaseQuantity(${index})">+</button>
            </td>
            <td>Rs ${item.itemTotal.toFixed(2)}</td>
            <td><button onclick="deleteItem(${index})">Delete</button></td>
        `;
        tableBody.appendChild(row);
        totalOrder += item.itemTotal;
    });

    table.appendChild(tableBody);
    orderItemsContainer.appendChild(table);

    // Update totals
    totalAmount.textContent = totalOrder.toFixed(2);
    totalPriceInput.value = totalOrder.toFixed(2);
    orderedItemsInput.value = JSON.stringify(orderedItems);
}

function decreaseQuantity(index) {
    if (orderedItems[index].quantity > 1) {
        orderedItems[index].quantity--;
        orderedItems[index].itemTotal = orderedItems[index].itemPrice * orderedItems[index].quantity;
        updateOrderSummary();
    }
}

function increaseQuantity(index) {
    orderedItems[index].quantity++;
    orderedItems[index].itemTotal = orderedItems[index].itemPrice * orderedItems[index].quantity;
    updateOrderSummary();
}

function deleteItem(index) {
    orderedItems.splice(index, 1);
    updateOrderSummary();
}
</script>

</body>
</html>
