<?php
include 'db_connection.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['item_id'])) {
    $item_id = $_GET['item_id'];
    $sql = "SELECT item_id, item_name, item_price, item_availability FROM Menu WHERE item_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo "Menu item not found.";
        exit;
    }

    $menu_item = $result->fetch_assoc();
} else {
    echo "Item ID is not set.";
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_id = $_POST['item-id'];
    $new_name = $_POST['item-name'];
    $new_price = $_POST['item-price'];
    $new_availability = $_POST['item-availability'];

    $update_sql = "UPDATE Menu SET item_id = ?, item_name = ?, item_price = ?, item_availability = ? WHERE item_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("isdsi", $new_id, $new_name, $new_price, $new_availability, $item_id);
    
    if ($update_stmt->execute()) {
        header("Location: index.php"); 
        exit;
    } else {
        echo "Error updating menu item: " . htmlspecialchars($conn->error);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e0f7fa; 
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
        }
        h1 {
            text-align: center;
            color: #00796b; 
        }
        label {
            display: block;
            margin: 10px 0 5px;
            color: #004d40; 
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #0288d1; 
            border-radius: 5px;
        }
        button {

            display: flex;
            background-color: #0288d1; 
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }
        button:hover {
            background-color: #0277bd; 
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Edit Menu Item</h1>
    <form method="POST">
        <label for="item-id">Item ID:</label>
        <input type="number" id="item-id" name="item-id" value="<?php echo htmlspecialchars($menu_item['item_id']); ?>" required />

        <label for="item-name">Item Name:</label>
        <input type="text" id="item-name" name="item-name" value="<?php echo htmlspecialchars($menu_item['item_name']); ?>" required />

        <label for="item-price">Item Price:</label>
        <input type="number" id="item-price" name="item-price" value="<?php echo htmlspecialchars($menu_item['item_price']); ?>" required />

        <label for="item-availability">Item Availability:</label>
        <select id="item-availability" name="item-availability" required>
            <option value="Available" <?php if ($menu_item['item_availability'] === 'Available') echo 'selected'; ?>>Available</option>
            <option value="Unavailable" <?php if ($menu_item['item_availability'] === 'Unavailable') echo 'selected'; ?>>Unavailable</option>
        </select>
        <button type="submit">Update Item</button><br><br>
        <button type="submit" onclick="window.location.href='index.php';">Back to home</button>
    </form>
</div>

</body>
</html>
