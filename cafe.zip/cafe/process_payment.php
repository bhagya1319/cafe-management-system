<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'db_connection.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $username_sql = "SELECT username FROM User WHERE user_id = ?";
    $stmt = $conn->prepare($username_sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $customer_name = $_POST['customer-name'] ;
        $phone_number = $_POST['phone-number'];
        $table_number = $_POST['table-number'];
        $total_amount = $_POST['total-price'];
        $payment_type = $_POST['payment-type'];
        $order_date = date('Y-m-d H:i:s');
        $ordered_items = json_decode($_POST['ordered-items'], true);
        $conn->begin_transaction();

        $order_sql = "INSERT INTO Orders (user_id, table_number, total_amount, payment_status, order_date) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($order_sql);
        $stmt->bind_param("iiss", $user_id, $table_number, $total_amount, $payment_type);
        $stmt->execute();
        $order_id = $conn->insert_id;
        $stmt->close();

        $customer_sql = "INSERT INTO Customers (order_id, customer_name, phone_number) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($customer_sql);
        $stmt->bind_param("iss", $order_id, $customer_name, $phone_number);
        $stmt->execute();
        $stmt->close();

        foreach ($ordered_items as $item) {
            $item_id = $item['itemId'];
            $item_name = $item['itemName'];
            $item_price = $item['itemPrice'];
            $quantity = $item['quantity'];
            $item_total = $item_price * $quantity;

            $order_item_sql = "INSERT INTO OrderItems (order_id, item_id, item_name, item_price, quantity, item_total) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($order_item_sql);
            $stmt->bind_param("iisdis", $order_id, $item_id, $item_name, $item_price, $quantity, $item_total);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();

        $display_order_date = date('d-m-y', strtotime($order_date));
        echo '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Order Confirmation</title>
            <style>
                body {
                font-family: Arial, sans-serif;
                background-color: #e9ecef;
                 margin: 0;
                padding: 0; 
                }

                .container {
                    background-color: #fff;
                    border-radius: 10px;
                    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
                    padding: 30px;
                    max-width: 600px;
                    margin: 50px auto;
                }
                    .cafe{
                     text-align:center;}
                h2 {
                    text-align: center;
                    color: #00796b;
                    margin-bottom: 20px;
                }
                p {
                    font-size: 16px;
                    line-height: 1.5;
                    color: #555;
                    margin: 10px 0;
                }
                button {
                    margin: 10px;
                    padding: 10px 15px;
                    font-size: 16px;
                    cursor: pointer;
                    background-color: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    transition: background-color 0.3s ease;
                }
                button:hover {
                    background-color: #45a049;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    padding: 10px;
                    text-align: left;
                    border: 1px solid #ddd;
                }
                th {
                    background-color: #00796b;
                    color: white;
                }
                .total-row {
                    background-color: #f2f2f2;
                    font-weight: bold;
                }
                @media print {
    button {
        display: none;
    }
}
            </style>
        </head>
        <body>
               
            <div class="container">
            <div class="cafe">
                <h2>Welcome to Cafe Delight</h2>
                <label>Address: JORHAT,ASSAM</label><br><br>
                <label>Contact Number: 8011425911</label><br><br>
                <label>GST Number: ER6878HJ687</label>
               </div>
                <h2>Order placed successfully!</h2>
                <p><strong>Order Date:</strong> ' . htmlspecialchars($display_order_date) . '</p>
                <p><strong>Order ID:</strong> ' . htmlspecialchars($order_id) . '</p>
                <p><strong>Employee ID:</strong> ' . htmlspecialchars($user_id) . '</p>
                <p><strong>Employee name:</strong> ' . htmlspecialchars($username) . '</p>
                <p><strong>Customer Name:</strong> ' . htmlspecialchars($customer_name) . '</p>
                <p><strong>Phone Number:</strong> ' . htmlspecialchars($phone_number) . '</p>
                <p><strong>Table Number:</strong> ' . htmlspecialchars($table_number) . '</p>
                <p><strong>Total Amount:</strong> Rs ' . htmlspecialchars($total_amount) . '</p>
                <p><strong>Payment Mode:</strong> ' . htmlspecialchars($payment_type) . '</p>

                <h3>Order Details:</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Item ID</th>
                            <th>Item Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>';

        foreach ($ordered_items as $item) {
            $item_total = $item['itemPrice'] * $item['quantity'];
            echo '<tr>
                    <td>' . htmlspecialchars($item['itemId']) . '</td>
                    <td>' . htmlspecialchars($item['itemName']) . '</td>
                    <td>Rs ' . htmlspecialchars($item['itemPrice']) . '</td>
                    <td>' . htmlspecialchars($item['quantity']) . '</td>
                    <td>Rs ' . htmlspecialchars($item_total) . '</td>
                </tr>';
        }

        echo '<tr class="total-row">
                <td colspan="4" style="text-align: right;">Total:</td>
                <td>Rs ' . htmlspecialchars($total_amount) . '</td>
            </tr>
        </tbody>
    </table>
    <button onclick="window.print()">Print Bill</button>
    <button onclick="window.location.href=\'index.php\'">Back to Menu</button>
</div>
</body>
</html>';
    } catch (Exception $e) {
        $conn->rollback();
        echo '<p class="error">Error placing order: ' . htmlspecialchars($e->getMessage()) . '</p>';
    } finally {
        $conn->close();
    }
}
?>
