<?php
session_start();
include 'db_connection.php';  

$username = $password = '';
$error_message = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        
        $sql = "SELECT user_id, username, password FROM User WHERE username = ? AND password = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $username,$password); 
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password == $user['password'] && $username==$user['username'] ){
                
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                header('Location: index.php');
                exit();
            }
            else {
                $error_message = "Incorrect username or password. Please try again.";
            }
        } else {
            $error_message = "Incorrect username or password. Please try again.";
        }
    // Close the prepared statement
        $stmt->close();
    } catch (Exception $e) {
        $error_message = "An error occurred. Please try again later.";
        error_log("Login error: " . $e->getMessage());
    }
}
session_regenerate_id(true);
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <style>
            body {
    font-family: Arial, sans-serif;
    background-color: #f4f7fc;
    background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
    background-size: cover;
    background-position: center;
    margin: 0;
    padding: 0;
    display: flex;                
    justify-content: center;      
    align-items: center;          
    height: 100vh;                
    text-align: center;           
}

 

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            position: relative;
        }



        label {
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            color: #333;
            text-align: center;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #6C63FF;
            outline: none;
        }

        button {
            margin-top: 20px;
            background-color: #6C63FF;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

    </style>
</head>
<body>
    
    <div class=container>
    <?php if (!empty($error_message)) : ?>
            <div style="color: red; margin-bottom: 15px; font-weight: bold;">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
   
    <form method="POST" action="">
    <h1>Welcome to Cafe Delight</h1>
        <label>Username: </label>   
        <input type="text" placeholder="Enter Username" name="username" required>  
        <br>

        <label>Password: </label>   
        <input type="password" placeholder="Enter Password" name="password" required>  
        <br>
     
        <button type="submit">LOGIN</button>
    </form>
    <p style="margin-top: 20px; font-size: 14px;">
    Don't have an account? <a href="signup.php" style="color: #6C63FF; text-decoration: none; font-weight: bold;">Sign Up</a><br><br>
    Forgot password? <a href="forgot_password.php" style="color: #6C63FF; text-decoration: none; font-weight: bold;">Forgot Password</a>
    </p>
    </div>     
</body>
</html>
