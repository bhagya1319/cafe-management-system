<?php
session_start();
include 'db_connection.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['category_name'])) {
    $category_name = $_GET['category_name'];

    // Begin transaction
    $conn->begin_transaction();

    try {
        $delete_items_sql = "DELETE FROM Menu WHERE category_name = ?";
        $stmt = $conn->prepare($delete_items_sql);
        $stmt->bind_param("s", $category_name);
        $stmt->execute();

        $delete_category_sql = "DELETE FROM Categories WHERE category_name = ?";
        $stmt = $conn->prepare($delete_category_sql);
        $stmt->bind_param("s", $category_name);
        $stmt->execute();
        $conn->commit();

        $_SESSION['message'] = "Category '$category_name' and its items were deleted successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['message'] = "Error deleting category: " . htmlspecialchars($e->getMessage());
    } finally {
        if (isset($stmt)) {
            $stmt->close();
        }
        $conn->close();
    }
} else {
    $_SESSION['message'] = "No category specified to delete.";
}
header("Location: index.php");
exit();
?>
