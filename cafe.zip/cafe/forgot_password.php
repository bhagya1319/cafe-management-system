<?php
include 'db_connection.php';

$user_id = $username = $retrieved_password = '';
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $username = $_POST['username'];

    try {
        $sql = "SELECT password FROM User WHERE user_id = ? AND username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('is', $user_id, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $retrieved_password = $user['password'];
            $success_message = "Your password is: " . htmlspecialchars($retrieved_password);
        } else {
            $error_message = "User ID or Username is incorrect. Please try again.";
        }
        $stmt->close();
    } catch (Exception $e) {
        $error_message = "An error occurred. Please try again later.";
        error_log("Forgot Password error: " . $e->getMessage());
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
            display: flex;                
            justify-content: center;      
            align-items: center;          
            height: 100vh;                
            text-align: center;  
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg');          
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            position: relative;
        }
        label {
            font-weight: bold;
            color: #555;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            color: #333;
            text-align: center;
        }
        input[type="text"]:focus {
            border-color: #6C63FF;
            outline: none;
        }
        button {
            margin-top: 20px;
            background-color: #6C63FF;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Forgot Password</h1>
        <?php if (!empty($error_message)) : ?>
            <div style="color: red; margin-bottom: 15px; font-weight: bold;">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($success_message)) : ?>
            <div style="color: green; margin-bottom: 15px; font-weight: bold;">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="">
            <label>User ID:</label>
            <input type="text" name="user_id" placeholder="Enter your User ID" required>
            <br>
            <label>Username:</label>
            <input type="text" name="username" placeholder="Enter your Username" required>
            <br>
            <button type="submit">Retrieve Password</button>
        </form>
        <p style="margin-top: 20px; font-size: 14px;">
            Back to <a href="login.php" style="color: #6C63FF; text-decoration: none; font-weight: bold;">Login</a>
        </p>
    </div>
</body>
</html>
