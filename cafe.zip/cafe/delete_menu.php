<?php
include 'db_connection.php';

if (isset($_GET['item_id']) && is_numeric($_GET['item_id'])) {
    $item_id = (int)$_GET['item_id']; 
    $stmt = $conn->prepare("DELETE FROM Menu WHERE item_id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $item_id);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "Item deleted successfully.";
        } else {
            echo "No item found with the given ID.";
        }

        $stmt->close();
    } else {
        echo "Failed to prepare statement.";
    }

    $conn->close();
    header("Location: index.php");
    exit();
}
?>
