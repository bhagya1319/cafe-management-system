<?php
include 'db_connection.php'; 


$user_id = $username = $password = $confirm_password = '';
$error_message = '';
$success_message = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    
    $user_id = $_POST['user_id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    
    if ($password !== $confirm_password) {
        $error_message = "Passwords do not match. Please try again.";
    } else {
        try {
            $sql = "SELECT user_id, password FROM User WHERE user_id = ? OR password = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('is', $user_id, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                
                $existing_user = $result->fetch_assoc();
                if ($existing_user['user_id'] == $user_id) {
                    $error_message = "User ID already exists. Please choose another.";
                } elseif ($existing_user['password'] == $password) {
                    $error_message = "Password already exists. Please choose another.";
                }
            } else {
                
                $sql = "INSERT INTO user (user_id, username, password) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('iss', $user_id, $username, $password);
                if ($stmt->execute()) {
                    $success_message = "Account created successfully! <a href='login.php'>Log in</a>";
                } else {
                    $error_message = "An error occurred. Please try again later.";
                }
            }
        } catch (Exception $e) {
            $error_message = "An error occurred. Please try again later.";
            error_log("Sign Up error: " . $e->getMessage());
        }
        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
            margin: 0;
            padding: 0;
            display: flex;                
            justify-content: center;      
            align-items: center;          
            height: 100vh;                
            text-align: center;           
        }

        .container {
            margin-top:70px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            position: relative;
        }

        .header {
            color: #6C63FF;
            font-size: 18px;
            font-weight: bold;
            position: absolute;
            top: -40px;                   
            left: 50%;
            transform: translateX(-50%); 
            background-color: #f4f7fc;    
            padding: 10px 20px;
            border-radius: 5px;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.1);
        }


        label {
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            color: #333;
            text-align: center;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #6C63FF;
            outline: none;
        }

        button {
            background-color: #6C63FF;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

    </style>
</head>
<body>
    <div class="container">
        <?php if (!empty($error_message)) : ?>
            <div style="color: red; margin-bottom: 15px; font-weight: bold;">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php elseif (!empty($success_message)) : ?>
            <div style="color: green; margin-bottom: 15px; font-weight: bold;">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        
        <form method="POST" action="">
            <h1>Create an Account</h1><br>
            <label>User ID: </label>   
            <input type="text" placeholder="Choose a User ID" name="user_id" required value="<?php echo htmlspecialchars($user_id); ?>">  
            <br>
            <label>Username: </label>   
            <input type="text" placeholder="Choose a Username" name="username" required value="<?php echo htmlspecialchars($username); ?>">  
            <br>

            <label>Password: </label>   
            <input type="password" placeholder="Create a Password" name="password" required value="<?php echo htmlspecialchars($password); ?>">  
            <br>

            <label>Confirm Password: </label>   
            <input type="password" placeholder="Confirm Your Password" name="confirm_password" required value="<?php echo htmlspecialchars($password); ?>">  
            <br>

            <button type="submit">Sign Up</button>
        </form>
        <p style="margin-top: 20px; font-size: 14px;">
            Already have an account? <a href="login.php" style="color: #6C63FF; text-decoration: none; font-weight: bold;">Log In</a>
        </p>
    </div>
</body>
</html>
