<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category_name = $_POST['new-category'];
    $stmt = $conn->prepare("INSERT INTO Categories (category_name) VALUES (?)");
    $stmt->bind_param("s", $category_name);

    if ($stmt->execute()) {
        echo "New category added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <style>
            body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f9;
    background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
}

.form-container {
    background: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
}

.form-container h1 {
    font-size: 1.5rem;
    margin-bottom: 20px;
    text-align: center;
    color: #333;
}

.form-container input[type="text"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-container input[type="submit"],
.form-container input[type="button"] {
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    margin: 10px 0;
}

.form-container input[type="submit"]:hover,
.form-container input[type="button"]:hover {
    background-color: #45a049;
}

.form-container a {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #007BFF;
    text-decoration: none;
}

.form-container a:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>
    <div class="form-container">
        <h1>Add New Category</h1>
        <form action="add_category.php" method="POST">
            <label for="new-category">Category Name:</label>
            <input type="text" id="new-category" name="new-category" placeholder="Enter category name" required>
            <input type="submit" value="Add Category">
            <input type="button" value="Back to home" onclick="window.location.href='index.php';">
        </form>
        </div>
</body>
</html>
