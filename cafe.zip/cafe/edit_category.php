<?php
include 'db_connection.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$original_name = ""; 
$new_name = ""; 
if (isset($_GET['category_name'])) {
    $original_name = $_GET['category_name'];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $original_name = $_POST['original-name']; 
    $new_name = $_POST['new-name'];

    if (!empty($new_name)) {
        $conn->begin_transaction();

        try {
        
        $update_category_sql = "UPDATE Categories SET category_name = ? WHERE category_name = ?";
        $update_category_stmt = $conn->prepare($update_category_sql);
        $update_category_stmt->bind_param("ss", $new_name, $original_name);
        $update_category_stmt->execute();
        $update_category_stmt->close();

        $update_menu_sql = "UPDATE Menu SET category_name = ? WHERE category_name = ?";
        $update_menu_stmt = $conn->prepare($update_menu_sql);
        $update_menu_stmt->bind_param("ss", $new_name, $original_name);
        $update_menu_stmt->execute();
        $update_menu_stmt->close();
        $conn->commit();
        header("Location: index.php");
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        echo "Error updating category: " . htmlspecialchars($e->getMessage());
    }
} else {
    echo "Category name cannot be empty.";
}
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f9;
    background-image: url('https://images.unsplash.com/photo-1569096651661-820d0de8b4ab?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&dl=mihai-moisa-Djtc1T38-GY-unsplash.jpg'); 
}

.form-container {
    background: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
}

.form-container h1 {
    font-size: 1.5rem;
    margin-bottom: 20px;
    text-align: center;
    color: #333;
}

.form-container input[type="text"] {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-container input[type="submit"],
.form-container input[type="button"] {
    background-color: #4CAF50;
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    margin: 10px 0;
}

.form-container input[type="submit"]:hover,
.form-container input[type="button"]:hover {
    background-color: #45a049;
}

.form-container a {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #007BFF;
    text-decoration: none;
}

.form-container a:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>
<div class="form-container">
        <h1>Edit Category</h1>
        <form action="edit_category.php" method="POST">
            <input type="hidden" name="original-name" value="<?php echo htmlspecialchars($original_name); ?>" />
            <label for="new-name">Category Name:</label>
            <input type="text" id="new-name" name="new-name" value="<?php echo htmlspecialchars($original_name); ?>" required >
            <input type="submit" value="Edit Category">
            <input type="button" value="Back to home" onclick="window.location.href='index.php';">
        </form>
    
</div>

</body>
</html>
